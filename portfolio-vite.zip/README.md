# Portfolio – React + Vite + Tailwind

## Come usare
1. **Installazione dipendenze**
   ```bash
   npm install
   ```
2. **Avvio in locale**
   ```bash
   npm run dev
   ```
3. **Build di produzione**
   ```bash
   npm run build
   npm run preview
   ```

## Deploy su Vercel
- Importa questo repository su Vercel → il build parte in automatico.
